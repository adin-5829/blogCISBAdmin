
<div class="container">
	<div class="specials">


		<div class="filter"><center>
			<h4><p style="padding-top:1em;padding-bottom:1.5em;font-family: 'Roboto Condensed', sans-serif;">Lihat kategori lain</p></h4>
			<div class="row">
				<div class="btn-group" role="group" aria-label="" style="font-family: 'Roboto Condensed', sans-serif;">
					<a href ="kategoriproduk.html"><button type="button" class="btn btn-default">Kategori 1</button></a>
					<a href ="kategoriproduk.html"><button type="button" class="btn btn-default">Kategori 2</button></a>
					<a href ="kategoriproduk.html"><button type="button" class="btn btn-default">Kategori 3</button></a>
					<a href ="kategoriproduk.html"><button type="button" class="btn btn-default">Kategori 4</button></a>
					<a href ="kategoriproduk.html"><button type="button" class="btn btn-default">Kategori 5</button></a>
					<a href ="kategoriproduk.html"><button type="button" class="btn btn-default">Kategori 6</button></a>
					<a href ="kategoriproduk.html"><button type="button" class="btn btn-default">Kategori 7</button></a>
					<a href ="kategoriproduk.html"><button type="button" class="btn btn-default">Kategori 8</button></a>
					<a href ="kategoriproduk.html"><button type="button" class="btn btn-default">Kategori 9</button></a>	
				</div>	
			</div>
		</center>
	</div>


	<h2 style="margin-top:1.5em;">Judul sesuai dengan nama kategori yang diklik</h2>
	<div class="special-top">
		<div class="col-md-3 special-in">
			<a href="detailproduk.html" ><img src="images/pi2.jpg" class="img-responsive" alt="">

			</a>
			<h5><a href="detailproduk.html">Ultra Diswash</a></h5>
			<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr,  sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>
		</div>
		<div class="col-md-3 special-in">
			<a href="detailproduk.html" ><img src="images/pi.jpg" class="img-responsive" alt="">

			</a>
			<h5><a href="detailproduk.html">Shampo mobil</a></h5>
			<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr,  sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>
		</div>
		<div class="col-md-3 special-in">
			<a href="detailproduk.html" ><img src="images/pi1.jpg" class="img-responsive" alt="">

			</a>
			<h5><a href="detailproduk.html">Pelicin Setrika</a></h5>
			<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr,  sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>
		</div>
		<div class="col-md-3 special-in">
			<a href="detailproduk.html" ><img src="images/pi4.jpg" class="img-responsive" alt="">

			</a>
			<h5><a href="detailproduk.html">Gass Clink</a></h5>
			<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr,  sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>
		</div>
		<div class="clearfix"> </div>
	</div>
	<div class="special-top">
		<div class="col-md-3 special-in">
			<a href="detailproduk.html" ><img src="images/pi3.jpg" class="img-responsive" alt="">

			</a>
			<h5><a href="detailproduk.html">Shampo mobil</a></h5>
			<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr,  sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>
		</div>
		<div class="col-md-3 special-in">
			<a href="detailproduk.html" ><img src="images/pi7.jpg" class="img-responsive" alt="">

			</a>
			<h5><a href="detailproduk.html">Gass Clink</a></h5>
			<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr,  sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>
		</div>
		<div class="col-md-3 special-in">
			<a href="detailproduk.html" ><img src="images/pi6.jpg" class="img-responsive" alt="">

			</a>
			<h5><a href="detailproduk.html">Pelicin Setrika</a></h5>
			<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr,  sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>
		</div>
		<div class="col-md-3 special-in">
			<a href="detailproduk.html" ><img src="images/pi5.jpg" class="img-responsive" alt="">

			</a>
			<h5><a href="detailproduk.html">Ultra Diswash</a></h5>
			<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr,  sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>
		</div>
		<div class="clearfix"> </div>
	</div>

	<!---->
	<div class="img-download">
		<center><a href ="#"><img src="images/download.png"></a><center>
		</div>
		<!---->


	</div>
</div>